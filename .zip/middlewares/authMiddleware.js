import JWT from "jsonwebtoken";
import userModel from "../models/userModel.js";

// it is a protected route on token base for protecting the user, in this we use next for authentication user
export const requireSignIn = async (req, res, next) => {
  try {
    //in which we decode the key we got authorization from headers and pass the jwt key
    const decode = JWT.verify(req.headers.authorization, process.env.JWT_KEY);
    req.user = decode;
    next();
  } catch (error) {
    console.log(error);
  }
};

// admin access midleware , agr wo admin hai to hi wo is route ko access kr sakta hai
export const isAdmin = async (req, res, next) => {
  try {
    const user = await userModel.findById(req.user._id);
    if (user.role !== 1) {
      return res.status(401).send({
        success: false,
        message: "UnAuthorized Access",
      });
    } else {
      next();
    }
  } catch (error) {
    console.log(error);
  }
};
