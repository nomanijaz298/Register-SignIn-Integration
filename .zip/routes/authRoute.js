import express from "express";
import {
  loginController,
  nomanController,
  registerController,
} from "../controllers/authController.js";
import { isAdmin, requireSignIn } from "../middlewares/authMiddleware.js";

//router object
const router = express.Router();

//routing
// register method
router.post("/register", registerController);

//login method
router.post("/login", loginController);

// test purpose
router.get("/test", requireSignIn, isAdmin, nomanController);

export default router;
