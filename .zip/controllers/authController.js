import { comparePassword, hashPassword } from "../helpers/authHelper.js";
import userModel from "../models/userModel.js";
import JWT from "jsonwebtoken";

export const registerController = async (req, res) => {
  try {
    //to get all the by de-structring method
    const { name, email, password, phone, address } = req.body;
    //first make sure about validations, it used to any user when register he should make sure his all entries
    if (!name) {
      return res.send({ message: "Name is required" });
    }
    if (!email) {
      return res.send({ message: "Email is required" });
    }
    if (!password) {
      return res.send({ message: "Password is required" });
    }
    if (!phone) {
      return res.send({ message: "Phone is required" });
    }
    if (!address) {
      return res.send({ message: "Address is required" });
    }

    //just check the user
    const existingUser = await userModel.findOne({ email });
    //check the existing user,if he/she already registered then render him to login page
    if (existingUser) {
      return res.status(200).send({
        success: false,
        message: "Already registered Please login",
      });
    }

    //in this api we registered the user, before registration first hashed the password
    const hashedPassword = await hashPassword(password);
    //after hashed we should save it, and pass all the data we get from user
    const user = await new userModel({
      name,
      email,
      phone,
      address,
      password: hashedPassword,
    }).save();
    res.status(201).send({
      success: true,
      message: "User Registered Successfully",
      user,
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Error in user Registeration",
      error,
    });
  }
};

//login controller
export const loginController = async (req, res) => {
  try {
    // login krne k lia email , password ki zarurat parti hai to inko de-structure kr le gay
    const { email, password } = req.body;
    //we do validation as up
    if (!email || !password) {
      return res.status(404).send({
        success: false,
        message: "Invalid email or password",
      });
    }

    // check user for login functionality on the basis of email , as we check it for register
    const user = await userModel.findOne({ email });
    if (!user) {
      return res.status(404).send({
        success: false,
        message: "Email is not Registered",
      });
    }

    //wo password jo hum ne hash kia tha ab us ko compare kre gay ku k us ko compare kr k hi hum user login krva sakte hai
    const compare = await comparePassword(password, user.password);
    if (!compare) {
      return res.status(400).send({
        success: false,
        message: "Invalid Password",
      });
    }
    //created token
    const token = await JWT.sign({ _id: user._id }, process.env.JWT_KEY, {
      expiresIn: "7d",
    });
    res.status(200).send({
      success: true,
      message: "login successfully",
      user: {
        name: user.name,
        email: user.email,
        phone: user.phone,
        address: user.address,
        password: user.password,
      },
      token,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error while login",
      error,
    });
  }
};

//test purpose controller
export const nomanController = (req, res) => {
  res.send("Protected Route");
};
